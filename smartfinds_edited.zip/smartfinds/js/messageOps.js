let messageList = new MessageListClass();

messageList.addMessageList (1, 102003, 103, 102, "Hi im interested in this. Can i deal via postage?", "2022-05-01 18:06:00");
messageList.addMessageList (2, 102003, 102, 103, "R u interested in 1 piece or all of them", "2022-05-01 18:07:00");
messageList.addMessageList (3, 102003, 103, 102, "This one only", "2022-05-01 18:06:00");
messageList.addMessageList (4, 102003, 102, 103, "I don't know how much is postage, I can go find out, will you pay for postage?", "2022-05-01 18:54:00");
messageList.addMessageList (5, 102003, 103, 102, "Yes", "2022-05-01 18:55:00");
messageList.addMessageList (6, 102003, 102, 103, "Normal, or registered post?", "2022-05-01 18:55:30");
messageList.addMessageList (7, 102003, 102, 103, "Would you prefer registered, u ok?", "2022-05-01 18:55:40");
messageList.addMessageList (8, 102003, 103, 102, "Registered", "2022-05-01 18:57:00");
messageList.addMessageList (9, 102003, 102, 103, "Ok I go check and let u know", "2022-05-01 18:57:30");
messageList.addMessageList (10, 102003, 102, 103, "Postage is additional $6, registered mail", "2022-05-05 17:26:00");
messageList.addMessageList (11, 102003, 103, 102, "Hi sorry for late reply as been busy with work. Ok can.", "2022-05-06 21:22:00");
messageList.addMessageList (11, 102003, 102, 103, "Can u make full payment and send me yr address?", "2022-05-06 21:22:30");




